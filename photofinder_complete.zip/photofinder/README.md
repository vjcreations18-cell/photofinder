# 📸 PhotoFinder — Face-Based Photo Finder

> Upload a selfie → AI finds all your photos from the event instantly.

---

## 🏗 Architecture Overview

```
Your Phone (APK)                    Your Computer / Server
┌────────────────────┐              ┌──────────────────────────────┐
│  Flutter App       │   WiFi/HTTP  │  FastAPI Backend             │
│  ─────────────     │◄────────────►│  ─────────────────────       │
│  1. Upload selfie  │              │  • InsightFace (ArcFace)     │
│  2. View results   │              │  • FAISS vector search       │
│  3. Share/download │              │  • OpenCV image processing   │
└────────────────────┘              │                              │
                                    │  /photos/  ← event photos   │
                                    │  /index/   ← FAISS index    │
                                    └──────────────────────────────┘
```

**Face Recognition Pipeline:**
```
Photo → InsightFace → 512-dim embedding → FAISS index
Selfie → InsightFace → 512-dim embedding → Cosine similarity search → Matches
```

---

## 📋 System Requirements

### For the Server (your laptop/PC):
- Python 3.9+
- 4GB+ RAM (8GB recommended for 10,000+ photos)
- 2GB disk space for models (auto-downloaded on first run)

### For the Phone:
- Android 5.0+ (API 21+)
- Same WiFi network as server

---

## 🚀 STEP 1: Server Setup

### 1a. Install Python dependencies

```bash
cd photofinder/backend
pip install -r requirements.txt
```

> First run downloads InsightFace models (~500MB) automatically.

### 1b. Add your photos

```bash
# Create photos folder and copy your event photos
mkdir -p photofinder/photos

# Copy photos from your '01' folder:
cp -r ~/Downloads/01/* photofinder/photos/

# Or on Windows:
# xcopy C:\Users\YourName\Downloads\01\* photofinder\photos\ /E
```

### 1c. Index the photos (one-time per event)

```bash
cd photofinder/backend
python index_photos.py --photos ../photos --workers 1

# For 1000 photos: ~5-10 minutes
# For 10000 photos: ~50-90 minutes
# Progress is shown live. Saves automatically every 100 photos.
```

### 1d. Start the server

```bash
cd photofinder/backend
uvicorn main:app --host 0.0.0.0 --port 8000

# You should see:
# INFO: Started server process
# INFO: Uvicorn running on http://0.0.0.0:8000
```

### 1e. Find your server IP

```bash
# Linux/Mac:
ip addr show | grep "inet " | grep -v 127.0.0.1

# Windows:
ipconfig | findstr IPv4

# Example output: 192.168.1.105
# Your server URL will be: http://192.168.1.105:8000
```

### 1f. Verify server is running

Open in browser: `http://YOUR_IP:8000`  
You should see: `{"app":"PhotoFinder","version":"1.0.0",...}`

---

## 📱 STEP 2: Build the Android APK

### 2a. Install Flutter (one-time)

**Linux:**
```bash
cd ~
git clone https://github.com/flutter/flutter.git -b stable
export PATH="$PATH:$HOME/flutter/bin"
# Add to ~/.bashrc to make permanent
```

**Windows:** Download Flutter from https://flutter.dev → extract → add to PATH

**Mac:**
```bash
brew install flutter
```

### 2b. Set up Android toolchain

```bash
flutter doctor  # Check what's missing
# Install Android Studio if prompted
# Accept SDK licenses:
flutter doctor --android-licenses
```

### 2c. Build the APK

```bash
cd photofinder
bash build_apk.sh

# APK will be saved as: photofinder/PhotoFinder.apk
```

### 2d. Install on your Android phone

**Method A — USB cable:**
```bash
# Enable USB debugging on phone (Settings > Developer Options)
adb install PhotoFinder.apk
```

**Method B — File transfer:**
1. Copy `PhotoFinder.apk` to your phone (USB / WhatsApp / Google Drive)
2. On phone: tap the APK file
3. Allow "Install from unknown sources" when prompted
4. Tap Install

---

## 📲 STEP 3: Using the App

1. **Open PhotoFinder** on your Android phone
2. **Tap Settings** (gear icon) → Enter your server URL:  
   `http://192.168.1.105:8000` (use your server's IP)
3. Tap **Test Connection** → should show "Connected!"
4. Go back to main screen
5. **Tap "Upload Your Selfie"** → take/choose a clear selfie
6. Tap **"Find My Photos"**
7. Wait ~2-5 seconds → all your event photos appear! 🎉

---

## ⚙️ API Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Server info and status |
| `/health` | GET | Health check |
| `/search` | POST | **Upload selfie, get matching photos** |
| `/photos/list` | GET | List all indexed photos |
| `/photos/count` | GET | Count of photos and indexed faces |
| `/admin/index` | POST | Trigger re-indexing |
| `/admin/index/status` | GET | Check indexing progress |
| `/admin/index/reset` | DELETE | Reset index |

### Search API Example

```bash
curl -X POST http://localhost:8000/search \
  -F "selfie=@my_selfie.jpg" \
  -F "threshold=0.45"
```

Response:
```json
{
  "matches": [
    {
      "photo_url": "/photos/IMG_1234.jpg",
      "filename": "IMG_1234.jpg",
      "similarity": 0.8234,
      "face_count": 5
    }
  ],
  "total_matches": 23,
  "query_time_ms": 145.3,
  "selfie_faces_detected": 1
}
```

---

## 🔧 Configuration

### Similarity Threshold (most important tuning knob)

| Value | Effect | Use when |
|-------|--------|----------|
| 0.35 | Very loose | Poor lighting photos |
| 0.45 | Balanced ✅ | Default, works well |
| 0.55 | Moderate | Good photo quality |
| 0.65 | Strict | Very high quality photos |

### Environment Variables (backend)

```bash
PHOTOS_DIR=./photos            # Where event photos are stored
INDEX_DIR=./index_data         # Where FAISS index is saved  
SIMILARITY_THRESHOLD=0.45      # Default threshold
MAX_RESULTS=100                # Max photos returned
```

---

## 🐳 Docker Deployment (Optional)

```bash
cd photofinder

# Copy photos first
cp -r ~/Downloads/01/* photos/

# Build and start
docker-compose up -d

# Index photos
docker exec photofinder-backend python index_photos.py --photos /app/photos

# Check logs
docker-compose logs -f
```

---

## 📊 Performance

| Photos | Indexing Time | Search Time | RAM |
|--------|--------------|-------------|-----|
| 500 | ~3 min | <1 sec | 2GB |
| 2,000 | ~12 min | <1 sec | 2GB |
| 5,000 | ~30 min | 1-2 sec | 3GB |
| 10,000 | ~60 min | 2-3 sec | 4GB |

- Indexing is done **once** per event
- Searching is always **instant** (FAISS is very fast)
- InsightFace ArcFace model: ~99% accuracy on clean selfies

---

## 🛠 Troubleshooting

**"No face detected in selfie"**
→ Use a clear, well-lit, front-facing photo. No sunglasses.

**"Cannot connect to server"**
→ Make sure phone and PC are on the same WiFi.  
→ Check firewall: `sudo ufw allow 8000` (Linux)  
→ Windows: Allow Python in Windows Firewall

**"No matches found"**  
→ Lower threshold to 0.35 in Settings  
→ Make sure photos are indexed: visit `http://SERVER:8000/photos/count`

**"Server offline"**  
→ Run `uvicorn main:app --host 0.0.0.0 --port 8000` on your PC  
→ Test from phone browser: `http://YOUR_IP:8000`

**APK install blocked**  
→ Settings → Apps → Special app access → Install unknown apps → Enable for your file manager

---

## 📁 Folder Structure

```
photofinder/
├── backend/
│   ├── main.py              # FastAPI server
│   ├── face_engine.py       # InsightFace + FAISS engine
│   ├── index_photos.py      # CLI bulk indexer
│   └── requirements.txt
├── flutter_app/
│   └── photofinder/
│       ├── lib/
│       │   ├── main.dart
│       │   ├── screens/
│       │   │   ├── home_screen.dart
│       │   │   ├── results_screen.dart
│       │   │   ├── photo_viewer_screen.dart
│       │   │   └── settings_screen.dart
│       │   ├── services/
│       │   │   └── api_service.dart
│       │   └── models/
│       │       └── search_result.dart
│       ├── android/
│       │   └── app/src/main/AndroidManifest.xml
│       └── pubspec.yaml
├── photos/                  # ← PUT YOUR EVENT PHOTOS HERE
├── index_data/              # Auto-created FAISS index
├── docker-compose.yml
├── build_apk.sh             # One-click APK builder
└── README.md
```

---

## 💡 Tips for Best Results

1. **Photos for indexing:** higher resolution = better accuracy
2. **Selfie:** use good lighting, face the camera directly
3. **Group photos:** works great — finds you even in large groups
4. **Multiple events:** run `python index_photos.py --photos ./photos_event2` and hit `/admin/index/reset` first to re-index for a different event
5. **Slow indexing?** Normal for first run (model download). Subsequent runs are fast.

---

## 🆓 100% Free Stack

| Component | Tool | Cost |
|-----------|------|------|
| Face recognition | InsightFace (ArcFace) | Free/MIT |
| Vector search | FAISS (Meta) | Free/MIT |
| Backend | FastAPI + Python | Free |
| Image processing | OpenCV | Free |
| Mobile app | Flutter | Free |
| Deployment | Your own PC/laptop | Free |

---

*Built with ❤️ for photographers and event attendees.*
