"""
PhotoFinder Backend - Face Recognition Photo Search
FastAPI + InsightFace + FAISS
"""

import os
import json
import time
import asyncio
import logging
from pathlib import Path
from typing import List, Optional
from contextlib import asynccontextmanager

import cv2
import numpy as np
import faiss
from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import aiofiles

from face_engine import FaceEngine

# ─── Config ───────────────────────────────────────────────────────────────────
PHOTOS_DIR = Path(os.getenv("PHOTOS_DIR", "./photos"))
INDEX_DIR = Path(os.getenv("INDEX_DIR", "./index_data"))
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "./uploads"))
SIMILARITY_THRESHOLD = float(os.getenv("SIMILARITY_THRESHOLD", "0.45"))
MAX_RESULTS = int(os.getenv("MAX_RESULTS", "100"))

for d in [PHOTOS_DIR, INDEX_DIR, UPLOAD_DIR]:
    d.mkdir(parents=True, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("photofinder")

# ─── Global State ─────────────────────────────────────────────────────────────
face_engine: Optional[FaceEngine] = None
index_status = {"indexed": 0, "total": 0, "status": "idle", "last_updated": None}


@asynccontextmanager
async def lifespan(app: FastAPI):
    global face_engine
    log.info("🚀 Starting PhotoFinder backend...")
    face_engine = FaceEngine(INDEX_DIR)
    face_engine.load_index()
    log.info(f"✅ Loaded index with {face_engine.get_index_size()} face embeddings")
    yield
    log.info("Shutting down...")


app = FastAPI(
    title="PhotoFinder API",
    description="Face-based photo search for events",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve photos statically
app.mount("/photos", StaticFiles(directory=str(PHOTOS_DIR)), name="photos")


# ─── Models ───────────────────────────────────────────────────────────────────
class IndexStatusResponse(BaseModel):
    indexed: int
    total: int
    status: str
    last_updated: Optional[str]


class MatchResult(BaseModel):
    photo_url: str
    filename: str
    similarity: float
    face_count: int


class SearchResponse(BaseModel):
    matches: List[MatchResult]
    total_matches: int
    query_time_ms: float
    selfie_faces_detected: int


# ─── Background Indexing ───────────────────────────────────────────────────────
def run_indexing():
    global index_status
    log.info("🔍 Starting photo indexing...")
    
    image_exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
    all_photos = [
        p for p in PHOTOS_DIR.rglob("*")
        if p.suffix.lower() in image_exts
    ]
    
    index_status["total"] = len(all_photos)
    index_status["status"] = "indexing"
    index_status["indexed"] = 0
    
    log.info(f"Found {len(all_photos)} photos to index")
    
    batch_size = 50
    for i in range(0, len(all_photos), batch_size):
        batch = all_photos[i:i + batch_size]
        for photo_path in batch:
            try:
                relative = str(photo_path.relative_to(PHOTOS_DIR))
                face_engine.index_photo(str(photo_path), relative)
                index_status["indexed"] += 1
            except Exception as e:
                log.warning(f"Failed to index {photo_path.name}: {e}")
        
        # Save index every 200 photos
        if i % 200 == 0 and i > 0:
            face_engine.save_index()
            log.info(f"Progress: {index_status['indexed']}/{index_status['total']}")
    
    face_engine.save_index()
    index_status["status"] = "done"
    index_status["last_updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
    log.info(f"✅ Indexing complete! {index_status['indexed']} photos processed")


# ─── API Endpoints ─────────────────────────────────────────────────────────────

@app.get("/", tags=["Health"])
def root():
    return {
        "app": "PhotoFinder",
        "version": "1.0.0",
        "status": "running",
        "index_size": face_engine.get_index_size() if face_engine else 0,
    }


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok", "indexed_faces": face_engine.get_index_size() if face_engine else 0}


@app.post("/admin/index", tags=["Admin"])
async def trigger_indexing(background_tasks: BackgroundTasks):
    """Trigger re-indexing of all photos in the photos directory."""
    if index_status["status"] == "indexing":
        raise HTTPException(400, "Indexing already in progress")
    background_tasks.add_task(run_indexing)
    return {"message": "Indexing started", "photos_dir": str(PHOTOS_DIR)}


@app.get("/admin/index/status", response_model=IndexStatusResponse, tags=["Admin"])
def indexing_status():
    return index_status


@app.post("/search", response_model=SearchResponse, tags=["Search"])
async def search_by_selfie(
    selfie: UploadFile = File(..., description="Selfie image to search for"),
    threshold: float = Query(SIMILARITY_THRESHOLD, ge=0.1, le=1.0),
    max_results: int = Query(MAX_RESULTS, ge=1, le=500),
):
    """
    Upload a selfie and find all photos containing that face.
    Returns matching photos sorted by similarity score.
    """
    if face_engine.get_index_size() == 0:
        raise HTTPException(503, "Photo index is empty. Ask admin to run /admin/index first.")
    
    # Save selfie temporarily
    ext = Path(selfie.filename).suffix or ".jpg"
    selfie_path = UPLOAD_DIR / f"selfie_{int(time.time()*1000)}{ext}"
    
    async with aiofiles.open(selfie_path, "wb") as f:
        content = await selfie.read()
        await f.write(content)
    
    start = time.time()
    
    try:
        # Generate embedding from selfie
        selfie_embeddings, face_count = face_engine.get_embeddings_from_file(str(selfie_path))
        
        if face_count == 0:
            raise HTTPException(400, "No face detected in selfie. Please upload a clear, front-facing photo.")
        
        if face_count > 1:
            log.info(f"Multiple faces in selfie ({face_count}), using the largest/most prominent face")
        
        # Search FAISS index
        raw_matches = face_engine.search(selfie_embeddings[0], top_k=max_results * 3, threshold=threshold)
        
        # Deduplicate by filename and keep best match per photo
        seen = {}
        for match in raw_matches:
            fname = match["filename"]
            if fname not in seen or match["similarity"] > seen[fname]["similarity"]:
                seen[fname] = match
        
        # Sort by similarity descending
        deduped = sorted(seen.values(), key=lambda x: x["similarity"], reverse=True)[:max_results]
        
        elapsed_ms = (time.time() - start) * 1000
        
        results = [
            MatchResult(
                photo_url=f"/photos/{m['filename']}",
                filename=m["filename"],
                similarity=round(m["similarity"], 4),
                face_count=m.get("face_count", 1),
            )
            for m in deduped
        ]
        
        log.info(f"Search complete: {len(results)} matches in {elapsed_ms:.0f}ms")
        
        return SearchResponse(
            matches=results,
            total_matches=len(results),
            query_time_ms=round(elapsed_ms, 1),
            selfie_faces_detected=face_count,
        )
    
    finally:
        selfie_path.unlink(missing_ok=True)


@app.get("/photos/list", tags=["Photos"])
def list_photos(page: int = 1, per_page: int = 50):
    """List all indexed photos with pagination."""
    image_exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
    all_photos = sorted([
        p.name for p in PHOTOS_DIR.iterdir()
        if p.suffix.lower() in image_exts
    ])
    total = len(all_photos)
    start = (page - 1) * per_page
    page_photos = all_photos[start:start + per_page]
    return {
        "photos": [{"filename": f, "url": f"/photos/{f}"} for f in page_photos],
        "total": total,
        "page": page,
        "per_page": per_page,
        "pages": (total + per_page - 1) // per_page,
    }


@app.get("/photos/count", tags=["Photos"])
def count_photos():
    image_exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
    count = sum(1 for p in PHOTOS_DIR.iterdir() if p.suffix.lower() in image_exts)
    return {"total_photos": count, "indexed_faces": face_engine.get_index_size()}


@app.delete("/admin/index/reset", tags=["Admin"])
def reset_index():
    """Reset the FAISS index (admin only)."""
    face_engine.reset_index()
    return {"message": "Index reset successfully"}
