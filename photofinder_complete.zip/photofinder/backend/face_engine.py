"""
Face Engine - InsightFace + FAISS
Handles embedding generation, indexing and search
"""

import os
import json
import pickle
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Optional

import cv2
import numpy as np
import faiss
import insightface
from insightface.app import FaceAnalysis

log = logging.getLogger("photofinder.engine")

EMBEDDING_DIM = 512  # InsightFace buffalo_l produces 512-dim embeddings


class FaceEngine:
    def __init__(self, index_dir: Path):
        self.index_dir = Path(index_dir)
        self.index_dir.mkdir(parents=True, exist_ok=True)
        
        self.index_path = self.index_dir / "faces.index"
        self.metadata_path = self.index_dir / "metadata.pkl"
        
        # FAISS index: Inner Product on L2-normalized vectors = cosine similarity
        self.faiss_index = faiss.IndexFlatIP(EMBEDDING_DIM)
        
        # Metadata: maps FAISS row ID → {filename, face_idx, face_count}
        self.metadata: List[Dict] = []
        
        # InsightFace model
        self._app: Optional[FaceAnalysis] = None
        self._init_model()
    
    def _init_model(self):
        """Initialize InsightFace model (downloads automatically first run)."""
        log.info("Loading InsightFace model (buffalo_l)...")
        try:
            self._app = FaceAnalysis(
                name="buffalo_l",
                providers=["CPUExecutionProvider"],
            )
            self._app.prepare(ctx_id=-1, det_size=(640, 640))
            log.info("✅ InsightFace model loaded")
        except Exception as e:
            log.error(f"Failed to load buffalo_l, trying buffalo_s: {e}")
            try:
                self._app = FaceAnalysis(
                    name="buffalo_s",
                    providers=["CPUExecutionProvider"],
                )
                self._app.prepare(ctx_id=-1, det_size=(640, 640))
                log.info("✅ InsightFace buffalo_s loaded")
            except Exception as e2:
                log.error(f"InsightFace init failed: {e2}")
                raise
    
    def _load_image(self, image_path: str) -> Optional[np.ndarray]:
        """Load image as RGB numpy array."""
        img = cv2.imread(image_path)
        if img is None:
            return None
        # InsightFace expects BGR (cv2 default), max dim 1280 for speed
        h, w = img.shape[:2]
        max_dim = 1280
        if max(h, w) > max_dim:
            scale = max_dim / max(h, w)
            img = cv2.resize(img, (int(w * scale), int(h * scale)))
        return img
    
    def get_embeddings(self, img: np.ndarray) -> Tuple[List[np.ndarray], int]:
        """
        Extract face embeddings from an image.
        Returns (list_of_embeddings, num_faces_detected)
        Each embedding is L2-normalized 512-dim float32 vector.
        """
        if self._app is None:
            raise RuntimeError("Face model not initialized")
        
        faces = self._app.get(img)
        
        if not faces:
            return [], 0
        
        embeddings = []
        for face in faces:
            emb = face.embedding
            if emb is None:
                continue
            # L2 normalize for cosine similarity via inner product
            norm = np.linalg.norm(emb)
            if norm > 0:
                emb = emb / norm
            embeddings.append(emb.astype(np.float32))
        
        return embeddings, len(faces)
    
    def get_embeddings_from_file(self, image_path: str) -> Tuple[List[np.ndarray], int]:
        """Load image from file and extract embeddings."""
        img = self._load_image(image_path)
        if img is None:
            raise ValueError(f"Could not load image: {image_path}")
        return self.get_embeddings(img)
    
    def index_photo(self, image_path: str, relative_filename: str):
        """
        Index all faces in a single photo.
        Adds face embeddings to FAISS and records metadata.
        """
        embeddings, face_count = self.get_embeddings_from_file(image_path)
        
        if not embeddings:
            return 0
        
        vectors = np.array(embeddings, dtype=np.float32)
        self.faiss_index.add(vectors)
        
        # Store metadata for each face
        for face_idx in range(len(embeddings)):
            self.metadata.append({
                "filename": relative_filename,
                "face_idx": face_idx,
                "face_count": face_count,
            })
        
        return len(embeddings)
    
    def search(
        self,
        query_embedding: np.ndarray,
        top_k: int = 300,
        threshold: float = 0.45,
    ) -> List[Dict]:
        """
        Search FAISS for nearest face matches.
        Returns list of dicts with filename, similarity score.
        """
        if self.faiss_index.ntotal == 0:
            return []
        
        actual_k = min(top_k, self.faiss_index.ntotal)
        
        query = query_embedding.astype(np.float32).reshape(1, -1)
        # Normalize query
        norm = np.linalg.norm(query)
        if norm > 0:
            query = query / norm
        
        scores, indices = self.faiss_index.search(query, actual_k)
        
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:
                continue
            similarity = float(score)  # Inner product of normalized = cosine similarity
            if similarity >= threshold:
                meta = self.metadata[idx]
                results.append({
                    "filename": meta["filename"],
                    "face_idx": meta["face_idx"],
                    "face_count": meta["face_count"],
                    "similarity": similarity,
                })
        
        return results
    
    def save_index(self):
        """Persist FAISS index and metadata to disk."""
        faiss.write_index(self.faiss_index, str(self.index_path))
        with open(self.metadata_path, "wb") as f:
            pickle.dump(self.metadata, f)
        log.info(f"Index saved: {self.faiss_index.ntotal} faces")
    
    def load_index(self):
        """Load FAISS index and metadata from disk."""
        if self.index_path.exists() and self.metadata_path.exists():
            self.faiss_index = faiss.read_index(str(self.index_path))
            with open(self.metadata_path, "rb") as f:
                self.metadata = pickle.load(f)
            log.info(f"Loaded index: {self.faiss_index.ntotal} faces, {len(self.metadata)} records")
        else:
            log.info("No existing index found, starting fresh")
    
    def reset_index(self):
        """Clear FAISS index and metadata."""
        self.faiss_index = faiss.IndexFlatIP(EMBEDDING_DIM)
        self.metadata = []
        if self.index_path.exists():
            self.index_path.unlink()
        if self.metadata_path.exists():
            self.metadata_path.unlink()
        log.info("Index reset")
    
    def get_index_size(self) -> int:
        return self.faiss_index.ntotal if self.faiss_index else 0
