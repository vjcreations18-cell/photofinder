#!/usr/bin/env python3
"""
Bulk photo indexer - run this to index photos before starting the server.
Usage: python index_photos.py --photos ./photos --workers 4
"""

import os
import sys
import time
import argparse
import logging
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("indexer")

from face_engine import FaceEngine


def index_single(args):
    engine, photo_path, relative = args
    try:
        count = engine.index_photo(str(photo_path), relative)
        return {"file": photo_path.name, "faces": count, "ok": True}
    except Exception as e:
        return {"file": photo_path.name, "faces": 0, "ok": False, "error": str(e)}


def main():
    parser = argparse.ArgumentParser(description="Index photos for face search")
    parser.add_argument("--photos", default="./photos", help="Directory containing photos")
    parser.add_argument("--index", default="./index_data", help="Directory to store index")
    parser.add_argument("--workers", type=int, default=2, help="Parallel workers (careful with RAM)")
    parser.add_argument("--save-every", type=int, default=100, help="Save index every N photos")
    args = parser.parse_args()

    photos_dir = Path(args.photos)
    if not photos_dir.exists():
        log.error(f"Photos directory not found: {photos_dir}")
        sys.exit(1)

    image_exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
    all_photos = [p for p in photos_dir.rglob("*") if p.suffix.lower() in image_exts]

    if not all_photos:
        log.error(f"No images found in {photos_dir}")
        sys.exit(1)

    log.info(f"Found {len(all_photos)} photos to index")

    engine = FaceEngine(Path(args.index))
    engine.load_index()

    start = time.time()
    processed = 0
    faces_found = 0
    errors = 0

    tasks = [
        (engine, p, str(p.relative_to(photos_dir)))
        for p in all_photos
    ]

    # Use single-threaded for reliability with ONNX
    for i, task in enumerate(tasks):
        result = index_single(task)
        processed += 1
        if result["ok"]:
            faces_found += result["faces"]
        else:
            errors += 1
            log.debug(f"Error: {result['file']} - {result.get('error', '')}")

        if processed % 50 == 0:
            elapsed = time.time() - start
            rate = processed / elapsed
            remaining = (len(all_photos) - processed) / rate if rate > 0 else 0
            log.info(
                f"Progress: {processed}/{len(all_photos)} "
                f"({processed/len(all_photos)*100:.1f}%) | "
                f"Faces: {faces_found} | "
                f"Rate: {rate:.1f} img/s | "
                f"ETA: {remaining/60:.1f}min"
            )

        if processed % args.save_every == 0:
            engine.save_index()
            log.info(f"Auto-saved index at {processed} photos")

    engine.save_index()

    elapsed = time.time() - start
    log.info("=" * 60)
    log.info(f"✅ Indexing complete!")
    log.info(f"   Photos processed: {processed}")
    log.info(f"   Faces indexed:    {faces_found}")
    log.info(f"   Errors:           {errors}")
    log.info(f"   Total time:       {elapsed/60:.1f} minutes")
    log.info(f"   Rate:             {processed/elapsed:.1f} photos/sec")
    log.info(f"   Index size:       {engine.get_index_size()} face vectors")
    log.info("=" * 60)


if __name__ == "__main__":
    main()
