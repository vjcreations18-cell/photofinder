#!/bin/bash
# ============================================================
# PhotoFinder — Start Backend Server (Intel Mac)
# Run this whenever you want to start the server
# ============================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Ensure Flutter/Android on PATH (if needed)
export PATH="$PATH:$HOME/flutter/bin"
export ANDROID_HOME="$HOME/android-sdk"

echo ""
echo "╔══════════════════════════════════════╗"
echo "║   PhotoFinder Server                 ║"
echo "╚══════════════════════════════════════╝"
echo ""

# Show photo count
PHOTO_COUNT=$(find photos -type f \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" \) 2>/dev/null | wc -l | tr -d ' ')
INDEX_EXISTS=$([ -f "index_data/faces.index" ] && echo "YES" || echo "NO")

echo "  Photos folder:  $PHOTO_COUNT images"
echo "  Index ready:    $INDEX_EXISTS"
echo ""

# If no index, offer to index now
if [ "$INDEX_EXISTS" = "NO" ]; then
    if [ "$PHOTO_COUNT" -gt 0 ]; then
        echo "⚠️  No index found. Indexing $PHOTO_COUNT photos first..."
        echo "   (This runs once — ~5-60 min depending on photo count)"
        echo ""
        python3 backend/index_photos.py --photos photos --index index_data
    else
        echo "⚠️  No photos found in ./photos/"
        echo "   Copy your event photos to: $SCRIPT_DIR/photos/"
        echo ""
    fi
fi

# Get and display IP
MY_IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "UNKNOWN")

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Server URL for the app:"
echo ""
echo -e "  \033[1;32mhttp://$MY_IP:8000\033[0m"
echo ""
echo "  Enter this in: App → Settings → Server URL"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  Starting server... (Ctrl+C to stop)"
echo ""

uvicorn backend.main:app --host 0.0.0.0 --port 8000
