#!/bin/bash
set -e
echo "============================================"
echo " PhotoFinder Backend Server"
echo "============================================"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Install deps
echo "Installing dependencies..."
pip install -r backend/requirements.txt --break-system-packages 2>/dev/null || pip install -r backend/requirements.txt

# Copy photos from Downloads/01 if present
if [ -d "$HOME/Downloads/01" ]; then
    echo "Found ~/Downloads/01 — copying photos..."
    cp -r "$HOME/Downloads/01/"* photos/ 2>/dev/null || true
    echo "Photos copied."
fi

# Index if not already indexed
if [ ! -f "index_data/faces.index" ]; then
    echo ""
    echo "Indexing photos (one-time, ~5-60 min depending on count)..."
    python3 backend/index_photos.py --photos photos
fi

# Show IP
echo ""
echo "Your server IP addresses:"
ip addr show | grep "inet " | grep -v 127 | awk '{print "  http://" $2}' | sed 's/\/[0-9]*//' | awk '{print $0 ":8000"}'
echo ""
echo "Enter one of the above URLs in the app Settings."
echo ""

# Start
uvicorn backend.main:app --host 0.0.0.0 --port 8000
