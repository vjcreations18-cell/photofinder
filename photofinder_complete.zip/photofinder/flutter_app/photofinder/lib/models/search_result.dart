class MatchResult {
  final String photoUrl;
  final String filename;
  final double similarity;
  final int faceCount;

  MatchResult({
    required this.photoUrl,
    required this.filename,
    required this.similarity,
    required this.faceCount,
  });

  factory MatchResult.fromJson(Map<String, dynamic> json) {
    return MatchResult(
      photoUrl: json['photo_url'] ?? '',
      filename: json['filename'] ?? '',
      similarity: (json['similarity'] ?? 0.0).toDouble(),
      faceCount: json['face_count'] ?? 1,
    );
  }

  String get similarityPercent => '${(similarity * 100).toStringAsFixed(0)}%';

  String get confidenceLabel {
    if (similarity >= 0.75) return 'High';
    if (similarity >= 0.55) return 'Good';
    return 'Possible';
  }
}

class SearchResponse {
  final List<MatchResult> matches;
  final int totalMatches;
  final double queryTimeMs;
  final int selfiesFaceDetected;

  SearchResponse({
    required this.matches,
    required this.totalMatches,
    required this.queryTimeMs,
    required this.selfiesFaceDetected,
  });

  factory SearchResponse.fromJson(Map<String, dynamic> json) {
    final matchList = (json['matches'] as List<dynamic>? ?? [])
        .map((m) => MatchResult.fromJson(m as Map<String, dynamic>))
        .toList();
    return SearchResponse(
      matches: matchList,
      totalMatches: json['total_matches'] ?? 0,
      queryTimeMs: (json['query_time_ms'] ?? 0.0).toDouble(),
      selfiesFaceDetected: json['selfie_faces_detected'] ?? 0,
    );
  }
}
