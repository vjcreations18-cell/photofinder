import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../services/api_service.dart';
import '../models/search_result.dart';
import 'results_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  File? _selfieFile;
  bool _isSearching = false;
  double _uploadProgress = 0;
  ServerStatus? _serverStatus;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _checkServer();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _checkServer() async {
    final status = await ApiService.getStatus();
    if (mounted) setState(() => _serverStatus = status);
  }

  Future<void> _pickSelfie(ImageSource source) async {
    // Request permissions
    Permission perm = source == ImageSource.camera
        ? Permission.camera
        : Permission.photos;
    final status = await perm.request();
    if (!status.isGranted) {
      Fluttertoast.showToast(msg: 'Permission denied');
      return;
    }

    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: source,
      imageQuality: 90,
      maxWidth: 1080,
      maxHeight: 1080,
    );
    if (picked != null) {
      setState(() {
        _selfieFile = File(picked.path);
      });
    }
  }

  void _showPickerOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        margin: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(top: 12),
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Choose your selfie',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _PickerOption(
                  icon: Icons.camera_alt_rounded,
                  label: 'Camera',
                  color: const Color(0xFF6C63FF),
                  onTap: () {
                    Navigator.pop(context);
                    _pickSelfie(ImageSource.camera);
                  },
                ),
                _PickerOption(
                  icon: Icons.photo_library_rounded,
                  label: 'Gallery',
                  color: const Color(0xFF3B82F6),
                  onTap: () {
                    Navigator.pop(context);
                    _pickSelfie(ImageSource.gallery);
                  },
                ),
              ],
            ),
            const SizedBox(height: 28),
          ],
        ),
      ),
    );
  }

  Future<void> _search() async {
    if (_selfieFile == null) {
      Fluttertoast.showToast(msg: 'Please upload a selfie first');
      return;
    }
    if (_serverStatus != null && !_serverStatus!.isOnline) {
      Fluttertoast.showToast(
          msg: 'Server offline. Check Settings → Server URL');
      return;
    }

    setState(() {
      _isSearching = true;
      _uploadProgress = 0;
    });

    try {
      final result = await ApiService.searchByFace(
        selfieFile: _selfieFile!,
        onProgress: (p) => setState(() => _uploadProgress = p),
      );

      if (!mounted) return;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResultsScreen(
            searchResponse: result,
            selfieFile: _selfieFile!,
          ),
        ),
      );
    } catch (e) {
      Fluttertoast.showToast(
        msg: e.toString(),
        toastLength: Toast.LENGTH_LONG,
      );
    } finally {
      if (mounted) setState(() => _isSearching = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.background,
      appBar: AppBar(
        title: const Text(
          'PhotoFinder',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_rounded),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
              _checkServer();
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Server status banner
            _ServerStatusBanner(status: _serverStatus),
            const SizedBox(height: 24),

            // Hero illustration / selfie preview
            Center(
              child: GestureDetector(
                onTap: _showPickerOptions,
                child: AnimatedBuilder(
                  animation: _pulseAnim,
                  builder: (_, child) => Transform.scale(
                    scale: _selfieFile == null ? _pulseAnim.value : 1.0,
                    child: child,
                  ),
                  child: _SelfieWidget(file: _selfieFile),
                ),
              ),
            ),
            const SizedBox(height: 28),

            // Upload selfie button
            OutlinedButton.icon(
              onPressed: _showPickerOptions,
              icon: const Icon(Icons.add_a_photo_rounded),
              label: Text(
                _selfieFile == null ? 'Upload Your Selfie' : 'Change Selfie',
                style: const TextStyle(fontSize: 15),
              ),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                side: BorderSide(
                  color: theme.colorScheme.primary,
                  width: 2,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Search button
            _SearchButton(
              isSearching: _isSearching,
              progress: _uploadProgress,
              hasSelfie: _selfieFile != null,
              onPressed: _search,
            ),
            const SizedBox(height: 36),

            // How it works section
            _HowItWorks(),
          ],
        ),
      ),
    );
  }
}

class _SelfieWidget extends StatelessWidget {
  final File? file;
  const _SelfieWidget({this.file});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 180,
      height: 180,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          colors: [Color(0xFF6C63FF), Color(0xFF3B82F6)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF6C63FF).withOpacity(0.4),
            blurRadius: 30,
            spreadRadius: 5,
          ),
        ],
      ),
      child: file == null
          ? const Icon(Icons.face_rounded, size: 80, color: Colors.white)
          : ClipOval(
              child: Image.file(
                file!,
                fit: BoxFit.cover,
                width: 180,
                height: 180,
              ),
            ),
    );
  }
}

class _PickerOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _PickerOption({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(icon, color: color, size: 36),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _SearchButton extends StatelessWidget {
  final bool isSearching;
  final double progress;
  final bool hasSelfie;
  final VoidCallback onPressed;

  const _SearchButton({
    required this.isSearching,
    required this.progress,
    required this.hasSelfie,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      decoration: BoxDecoration(
        gradient: hasSelfie
            ? const LinearGradient(
                colors: [Color(0xFF6C63FF), Color(0xFF3B82F6)])
            : null,
        color: hasSelfie ? null : Colors.grey[300],
        borderRadius: BorderRadius.circular(16),
        boxShadow: hasSelfie
            ? [
                BoxShadow(
                  color: const Color(0xFF6C63FF).withOpacity(0.4),
                  blurRadius: 16,
                  spreadRadius: 2,
                  offset: const Offset(0, 6),
                )
              ]
            : null,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: hasSelfie && !isSearching ? onPressed : null,
          child: Center(
            child: isSearching
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          value: progress > 0 ? progress : null,
                          strokeWidth: 2.5,
                          color: Colors.white,
                        ),
                      ),
                      if (progress > 0 && progress < 1)
                        Text(
                          '${(progress * 100).toInt()}%',
                          style: const TextStyle(
                              color: Colors.white, fontSize: 11),
                        ),
                    ],
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.search_rounded,
                        color: hasSelfie ? Colors.white : Colors.grey[600],
                        size: 22,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Find My Photos',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: hasSelfie ? Colors.white : Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

class _ServerStatusBanner extends StatelessWidget {
  final ServerStatus? status;

  const _ServerStatusBanner({this.status});

  @override
  Widget build(BuildContext context) {
    if (status == null) {
      return const SizedBox(height: 4);
    }

    if (status!.isOnline) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.green.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.green.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            const Icon(Icons.cloud_done_rounded,
                color: Colors.green, size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'Server online • ${status!.indexedFaces} faces indexed',
                style: const TextStyle(
                    color: Colors.green, fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
      );
    } else {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.orange.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.orange.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            const Icon(Icons.cloud_off_rounded,
                color: Colors.orange, size: 18),
            const SizedBox(width: 8),
            const Expanded(
              child: Text(
                'Server offline — tap Settings to configure',
                style: TextStyle(
                    color: Colors.orange, fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
      );
    }
  }
}

class _HowItWorks extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final steps = [
      (Icons.face_rounded, 'Upload Selfie', 'Take or pick a photo of yourself'),
      (Icons.manage_search_rounded, 'AI Scans', 'Our AI scans all event photos'),
      (Icons.photo_library_rounded, 'Get Results', 'See all photos with your face'),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'How it works',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        ...steps.asMap().entries.map((e) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: const Color(0xFF6C63FF).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(e.value.$1,
                        color: const Color(0xFF6C63FF), size: 22),
                  ),
                  const SizedBox(width: 14),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(e.value.$2,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14)),
                      Text(e.value.$3,
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 12)),
                    ],
                  ),
                ],
              ),
            )),
      ],
    );
  }
}
