import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shimmer/shimmer.dart';
import '../models/search_result.dart';
import '../services/api_service.dart';
import 'photo_viewer_screen.dart';

class ResultsScreen extends StatefulWidget {
  final SearchResponse searchResponse;
  final File selfieFile;

  const ResultsScreen({
    super.key,
    required this.searchResponse,
    required this.selfieFile,
  });

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  bool _isGridView = true;

  List<MatchResult> get matches => widget.searchResponse.matches;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.background,
      appBar: AppBar(
        title: Text(
          '${matches.length} Photos Found',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: Icon(
              _isGridView ? Icons.view_list_rounded : Icons.grid_view_rounded,
            ),
            onPressed: () => setState(() => _isGridView = !_isGridView),
          ),
        ],
      ),
      body: Column(
        children: [
          // Stats bar
          _StatsBar(
            response: widget.searchResponse,
            selfieFile: widget.selfieFile,
          ),

          // Results
          Expanded(
            child: matches.isEmpty
                ? _EmptyState()
                : _isGridView
                    ? _PhotoGrid(matches: matches)
                    : _PhotoList(matches: matches),
          ),
        ],
      ),
    );
  }
}

class _StatsBar extends StatelessWidget {
  final SearchResponse response;
  final File selfieFile;

  const _StatsBar({required this.response, required this.selfieFile});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      color: const Color(0xFF6C63FF).withOpacity(0.06),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: Image.file(
              selfieFile,
              width: 44,
              height: 44,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${response.totalMatches} photos found',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
                Text(
                  'Searched in ${response.queryTimeMs.toStringAsFixed(0)}ms',
                  style: const TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ],
            ),
          ),
          if (response.totalMatches > 0)
            TextButton.icon(
              icon: const Icon(Icons.share_rounded, size: 18),
              label: const Text('Share'),
              onPressed: () {
                Share.share(
                  'Found ${response.totalMatches} photos of me at the event! 📸',
                );
              },
            ),
        ],
      ),
    );
  }
}

class _PhotoGrid extends StatelessWidget {
  final List<MatchResult> matches;
  const _PhotoGrid({required this.matches});

  @override
  Widget build(BuildContext context) {
    return MasonryGridView.count(
      padding: const EdgeInsets.all(8),
      crossAxisCount: 2,
      mainAxisSpacing: 8,
      crossAxisSpacing: 8,
      itemCount: matches.length,
      itemBuilder: (_, i) => _PhotoCard(match: matches[i], index: i, allMatches: matches),
    );
  }
}

class _PhotoList extends StatelessWidget {
  final List<MatchResult> matches;
  const _PhotoList({required this.matches});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.all(12),
      itemCount: matches.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) => _PhotoListTile(match: matches[i], index: i, allMatches: matches),
    );
  }
}

class _PhotoCard extends StatelessWidget {
  final MatchResult match;
  final int index;
  final List<MatchResult> allMatches;

  const _PhotoCard({required this.match, required this.index, required this.allMatches});

  @override
  Widget build(BuildContext context) {
    final fullUrl = ApiService.photoUrl(match.filename);

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PhotoViewerScreen(
            matches: allMatches,
            initialIndex: index,
          ),
        ),
      ),
      child: Hero(
        tag: 'photo_$index',
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Stack(
            children: [
              CachedNetworkImage(
                imageUrl: fullUrl,
                fit: BoxFit.cover,
                placeholder: (_, __) => Shimmer.fromColors(
                  baseColor: Colors.grey[300]!,
                  highlightColor: Colors.grey[100]!,
                  child: Container(
                    height: 160,
                    color: Colors.white,
                  ),
                ),
                errorWidget: (_, __, ___) => Container(
                  height: 160,
                  color: Colors.grey[200],
                  child: const Icon(Icons.broken_image_rounded,
                      color: Colors.grey, size: 40),
                ),
              ),
              Positioned(
                top: 6,
                right: 6,
                child: _ConfidenceBadge(match: match),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PhotoListTile extends StatelessWidget {
  final MatchResult match;
  final int index;
  final List<MatchResult> allMatches;

  const _PhotoListTile({required this.match, required this.index, required this.allMatches});

  @override
  Widget build(BuildContext context) {
    final fullUrl = ApiService.photoUrl(match.filename);

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PhotoViewerScreen(
            matches: allMatches,
            initialIndex: index,
          ),
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 8,
              offset: const Offset(0, 2),
            )
          ],
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(14),
                bottomLeft: Radius.circular(14),
              ),
              child: CachedNetworkImage(
                imageUrl: fullUrl,
                width: 90,
                height: 90,
                fit: BoxFit.cover,
                placeholder: (_, __) => Shimmer.fromColors(
                  baseColor: Colors.grey[300]!,
                  highlightColor: Colors.grey[100]!,
                  child: Container(width: 90, height: 90, color: Colors.white),
                ),
                errorWidget: (_, __, ___) => Container(
                  width: 90,
                  height: 90,
                  color: Colors.grey[200],
                  child: const Icon(Icons.broken_image_rounded, color: Colors.grey),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    match.filename.split('/').last,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 13),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      _ConfidenceBadge(match: match, small: true),
                      const SizedBox(width: 8),
                      Text(
                        '${match.faceCount} face${match.faceCount != 1 ? 's' : ''} in photo',
                        style:
                            const TextStyle(color: Colors.grey, fontSize: 11),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(right: 12),
              child: Icon(Icons.chevron_right_rounded, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

class _ConfidenceBadge extends StatelessWidget {
  final MatchResult match;
  final bool small;

  const _ConfidenceBadge({required this.match, this.small = false});

  Color get color {
    if (match.similarity >= 0.75) return Colors.green;
    if (match.similarity >= 0.55) return Colors.orange;
    return Colors.blue;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: small ? 6 : 8,
        vertical: small ? 2 : 4,
      ),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        match.similarityPercent,
        style: TextStyle(
          color: Colors.white,
          fontSize: small ? 10 : 11,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.search_off_rounded,
              size: 80, color: Colors.grey[400]),
          const SizedBox(height: 16),
          const Text(
            'No matches found',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Try a clearer, front-facing selfie\nor lower the threshold in Settings',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
