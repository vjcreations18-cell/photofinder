import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../services/api_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _urlController;
  late TextEditingController _thresholdController;
  bool _testing = false;
  ServerStatus? _testResult;

  @override
  void initState() {
    super.initState();
    _urlController = TextEditingController(text: ApiService.baseUrl);
    _thresholdController = TextEditingController(text: '0.45');
  }

  @override
  void dispose() {
    _urlController.dispose();
    _thresholdController.dispose();
    super.dispose();
  }

  Future<void> _testConnection() async {
    ApiService.setBaseUrl(_urlController.text.trim());
    setState(() {
      _testing = true;
      _testResult = null;
    });
    final status = await ApiService.getStatus();
    setState(() {
      _testing = false;
      _testResult = status;
    });
  }

  void _save() {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      Fluttertoast.showToast(msg: 'Enter a valid server URL');
      return;
    }
    ApiService.setBaseUrl(url);
    Fluttertoast.showToast(msg: 'Settings saved');
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings',
            style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Server URL section
            const _SectionHeader(title: 'Server Configuration'),
            const SizedBox(height: 12),
            const Text(
              'Enter the IP address and port of your PhotoFinder backend server.',
              style: TextStyle(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _urlController,
              keyboardType: TextInputType.url,
              decoration: InputDecoration(
                labelText: 'Server URL',
                hintText: 'http://192.168.1.100:8000',
                prefixIcon: const Icon(Icons.dns_rounded),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _testing ? null : _testConnection,
                icon: _testing
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.wifi_tethering_rounded),
                label: Text(_testing ? 'Testing...' : 'Test Connection'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            if (_testResult != null) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _testResult!.isOnline
                      ? Colors.green.withOpacity(0.1)
                      : Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Icon(
                      _testResult!.isOnline
                          ? Icons.check_circle_rounded
                          : Icons.error_rounded,
                      color:
                          _testResult!.isOnline ? Colors.green : Colors.red,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      _testResult!.isOnline
                          ? 'Connected! ${_testResult!.indexedFaces} faces indexed'
                          : 'Connection failed. Check URL and server status.',
                      style: TextStyle(
                        color: _testResult!.isOnline
                            ? Colors.green
                            : Colors.red,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 28),

            // Quick-connect tips
            const _SectionHeader(title: 'Quick Connect'),
            const SizedBox(height: 10),
            _QuickConnectTile(
              label: 'Local WiFi (same network)',
              example: 'http://192.168.1.X:8000',
              onTap: () {
                _urlController.text = 'http://192.168.1.100:8000';
              },
            ),
            _QuickConnectTile(
              label: 'USB Tethering',
              example: 'http://192.168.42.129:8000',
              onTap: () {
                _urlController.text = 'http://192.168.42.129:8000';
              },
            ),
            _QuickConnectTile(
              label: 'Localhost (emulator only)',
              example: 'http://10.0.2.2:8000',
              onTap: () {
                _urlController.text = 'http://10.0.2.2:8000';
              },
            ),

            const SizedBox(height: 28),

            // Search settings
            const _SectionHeader(title: 'Search Settings'),
            const SizedBox(height: 12),
            const Text(
              'Similarity threshold (0.1=loose to 1.0=strict). Default: 0.45',
              style: TextStyle(color: Colors.grey, fontSize: 13),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _thresholdController,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'Similarity Threshold',
                hintText: '0.45',
                prefixIcon: const Icon(Icons.tune_rounded),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
              ),
            ),

            const SizedBox(height: 36),

            // Save button
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _save,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6C63FF),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: const Text('Save Settings',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
    );
  }
}

class _QuickConnectTile extends StatelessWidget {
  final String label;
  final String example;
  final VoidCallback onTap;

  const _QuickConnectTile({
    required this.label,
    required this.example,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 4),
      leading: const Icon(Icons.bolt_rounded, color: Color(0xFF6C63FF)),
      title: Text(label,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
      subtitle: Text(example,
          style: const TextStyle(fontSize: 11, color: Colors.grey)),
      onTap: onTap,
      dense: true,
    );
  }
}
