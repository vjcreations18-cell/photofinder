import 'dart:io';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../models/search_result.dart';
import '../services/api_service.dart';

class PhotoViewerScreen extends StatefulWidget {
  final List<MatchResult> matches;
  final int initialIndex;

  const PhotoViewerScreen({
    super.key,
    required this.matches,
    required this.initialIndex,
  });

  @override
  State<PhotoViewerScreen> createState() => _PhotoViewerScreenState();
}

class _PhotoViewerScreenState extends State<PhotoViewerScreen> {
  late int _currentIndex;
  late PageController _pageController;
  bool _isDownloading = false;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  MatchResult get current => widget.matches[_currentIndex];

  Future<void> _downloadAndShare() async {
    setState(() => _isDownloading = true);
    try {
      final url = ApiService.photoUrl(current.filename);
      final dir = await getTemporaryDirectory();
      final fname = current.filename.split('/').last;
      final savePath = '${dir.path}/$fname';

      await Dio().download(url, savePath);

      final file = XFile(savePath);
      await Share.shareXFiles(
        [file],
        text: 'Found this photo using PhotoFinder! 📸',
      );
    } catch (e) {
      Fluttertoast.showToast(msg: 'Download failed: $e');
    } finally {
      if (mounted) setState(() => _isDownloading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.black.withOpacity(0.5),
        foregroundColor: Colors.white,
        title: Text(
          '${_currentIndex + 1} / ${widget.matches.length}',
          style: const TextStyle(fontSize: 14),
        ),
        actions: [
          IconButton(
            icon: _isDownloading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.share_rounded),
            onPressed: _isDownloading ? null : _downloadAndShare,
          ),
        ],
      ),
      body: Stack(
        children: [
          PhotoViewGallery.builder(
            pageController: _pageController,
            itemCount: widget.matches.length,
            onPageChanged: (i) => setState(() => _currentIndex = i),
            builder: (_, i) {
              final url = ApiService.photoUrl(widget.matches[i].filename);
              return PhotoViewGalleryPageOptions(
                imageProvider: CachedNetworkImageProvider(url),
                minScale: PhotoViewComputedScale.contained,
                maxScale: PhotoViewComputedScale.covered * 3,
                heroAttributes: PhotoViewHeroAttributes(tag: 'photo_$i'),
              );
            },
          ),
          // Bottom confidence bar
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [
                    Colors.black.withOpacity(0.8),
                    Colors.transparent,
                  ],
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: _confidenceColor(current.similarity),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '${current.similarityPercent} match',
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      current.filename.split('/').last,
                      style: const TextStyle(
                          color: Colors.white70, fontSize: 12),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _confidenceColor(double sim) {
    if (sim >= 0.75) return Colors.green;
    if (sim >= 0.55) return Colors.orange;
    return Colors.blue;
  }
}
