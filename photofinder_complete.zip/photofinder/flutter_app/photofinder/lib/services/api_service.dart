import 'dart:io';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import '../models/search_result.dart';

class ApiService {
  static String _baseUrl = 'http://192.168.1.100:8000'; // Default - user configures this

  static String get baseUrl => _baseUrl;

  static void setBaseUrl(String url) {
    _baseUrl = url.trimRight().replaceAll(RegExp(r'/$'), '');
  }

  static Dio get _dio => Dio(BaseOptions(
        baseUrl: _baseUrl,
        connectTimeout: const Duration(seconds: 30),
        receiveTimeout: const Duration(minutes: 5),
        sendTimeout: const Duration(minutes: 2),
      ));

  /// Upload selfie and search for matching photos
  static Future<SearchResponse> searchByFace({
    required File selfieFile,
    double threshold = 0.45,
    int maxResults = 100,
    void Function(double progress)? onProgress,
  }) async {
    try {
      final formData = FormData.fromMap({
        'selfie': await MultipartFile.fromFile(
          selfieFile.path,
          filename: 'selfie.jpg',
        ),
      });

      final response = await _dio.post(
        '/search',
        data: formData,
        queryParameters: {
          'threshold': threshold,
          'max_results': maxResults,
        },
        onSendProgress: (sent, total) {
          if (total > 0 && onProgress != null) {
            onProgress(sent / total);
          }
        },
      );

      if (response.statusCode == 200) {
        return SearchResponse.fromJson(response.data);
      } else {
        throw ApiException('Search failed: ${response.statusCode}');
      }
    } on DioException catch (e) {
      if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.connectionError) {
        throw ApiException(
            'Cannot connect to server. Check server URL in settings.');
      }
      final msg = e.response?.data?['detail'] ?? e.message ?? 'Network error';
      throw ApiException(msg.toString());
    }
  }

  /// Check server health and get index stats
  static Future<ServerStatus> getStatus() async {
    try {
      final response = await _dio.get('/health');
      return ServerStatus(
        isOnline: true,
        indexedFaces: response.data['indexed_faces'] ?? 0,
      );
    } catch (e) {
      return ServerStatus(isOnline: false, indexedFaces: 0);
    }
  }

  /// Get total photo count
  static Future<Map<String, dynamic>> getPhotoCount() async {
    final response = await _dio.get('/photos/count');
    return response.data;
  }

  /// Trigger indexing (admin)
  static Future<void> triggerIndexing() async {
    await _dio.post('/admin/index');
  }

  /// Get indexing status
  static Future<Map<String, dynamic>> getIndexStatus() async {
    final response = await _dio.get('/admin/index/status');
    return response.data;
  }

  /// Build full image URL
  static String photoUrl(String filename) {
    if (filename.startsWith('http')) return filename;
    return '$_baseUrl/photos/$filename';
  }
}

class ApiException implements Exception {
  final String message;
  ApiException(this.message);

  @override
  String toString() => message;
}

class ServerStatus {
  final bool isOnline;
  final int indexedFaces;

  ServerStatus({required this.isOnline, required this.indexedFaces});
}
