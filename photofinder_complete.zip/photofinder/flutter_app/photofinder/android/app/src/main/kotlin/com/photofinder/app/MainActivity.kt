package com.photofinder.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
