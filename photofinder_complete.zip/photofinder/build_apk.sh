#!/bin/bash
# ============================================================
# PhotoFinder APK Builder
# Run this script on your Linux/Mac machine to build the APK
# Usage: bash build_apk.sh
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() { echo -e "${BLUE}[PhotoFinder]${NC} $1"; }
ok()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn(){ echo -e "${YELLOW}[!]${NC} $1"; }
err() { echo -e "${RED}[✗]${NC} $1"; exit 1; }

echo ""
echo -e "${BLUE}================================================${NC}"
echo -e "${BLUE}   PhotoFinder APK Builder                     ${NC}"
echo -e "${BLUE}================================================${NC}"
echo ""

# ── Step 1: Check Flutter ──────────────────────────────────
log "Checking Flutter installation..."
if ! command -v flutter &> /dev/null; then
    err "Flutter not found. Install from https://flutter.dev/docs/get-started/install"
fi
FLUTTER_VER=$(flutter --version 2>&1 | head -1)
ok "Flutter found: $FLUTTER_VER"

# ── Step 2: Accept Android licenses ───────────────────────
log "Accepting Android SDK licenses..."
yes | flutter doctor --android-licenses 2>/dev/null || true
ok "Licenses accepted"

# ── Step 3: Navigate to flutter project ───────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$SCRIPT_DIR/flutter_app/photofinder"

if [ ! -d "$APP_DIR" ]; then
    err "Flutter app directory not found at: $APP_DIR"
fi

cd "$APP_DIR"
log "Building from: $APP_DIR"

# ── Step 4: Flutter doctor check ──────────────────────────
log "Running flutter doctor..."
flutter doctor -v 2>&1 | grep -E "(✓|✗|!|Android|Flutter)" | head -20
echo ""

# ── Step 5: Get dependencies ───────────────────────────────
log "Installing Flutter dependencies..."
flutter pub get
ok "Dependencies installed"

# ── Step 6: Build APK ─────────────────────────────────────
log "Building release APK (this takes 3-8 minutes first time)..."
flutter build apk --release --no-shrink 2>&1

# ── Step 7: Copy APK to output ────────────────────────────
APK_SRC="build/app/outputs/flutter-apk/app-release.apk"
APK_DST="$SCRIPT_DIR/PhotoFinder.apk"

if [ -f "$APK_SRC" ]; then
    cp "$APK_SRC" "$APK_DST"
    APK_SIZE=$(ls -lh "$APK_DST" | awk '{print $5}')
    echo ""
    echo -e "${GREEN}================================================${NC}"
    echo -e "${GREEN}   APK BUILD SUCCESSFUL! 🎉                    ${NC}"
    echo -e "${GREEN}================================================${NC}"
    echo ""
    ok "APK saved to: $APK_DST"
    ok "APK size: $APK_SIZE"
    echo ""
    echo -e "${YELLOW}📱 To install on Android:${NC}"
    echo "   adb install $APK_DST"
    echo ""
    echo -e "${YELLOW}   Or transfer the APK to your phone and tap to install${NC}"
    echo -e "${YELLOW}   (Enable 'Install from unknown sources' in Settings first)${NC}"
    echo ""
else
    err "APK not found at $APK_SRC. Build may have failed."
fi
