@echo off
echo ============================================
echo  PhotoFinder Backend Server
echo ============================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install from https://python.org
    pause
    exit /b 1
)

:: Install dependencies if needed
echo Installing dependencies...
pip install -r backend\requirements.txt

:: Copy photos if 01 folder exists in Downloads
if exist "%USERPROFILE%\Downloads\01" (
    echo Copying photos from Downloads\01...
    xcopy "%USERPROFILE%\Downloads\01\*" "photos\" /E /Y /Q
    echo Done.
)

:: Index photos
echo.
echo Indexing photos (this runs once per event)...
python backend\index_photos.py --photos photos

:: Start server
echo.
echo Starting server...
echo Open this URL on your phone: http://%COMPUTERNAME%:8000
echo Or find your IP with: ipconfig
echo.
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000
pause
