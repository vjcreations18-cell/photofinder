#!/bin/bash
# ============================================================
# PhotoFinder — Intel Mac Complete Setup Script
# Run this ONCE to install everything and build the APK
# Usage: bash mac_setup.sh
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log()  { echo -e "${BLUE}▶${NC} $1"; }
ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC}  $1"; }
err()  { echo -e "${RED}✗ ERROR:${NC} $1"; exit 1; }
hdr()  { echo -e "\n${BOLD}${CYAN}━━━ $1 ━━━${NC}\n"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo -e "${BOLD}${BLUE}╔══════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${BLUE}║   PhotoFinder — Intel Mac Setup          ║${NC}"
echo -e "${BOLD}${BLUE}╚══════════════════════════════════════════╝${NC}"
echo ""

# ── PHASE 1: Homebrew ─────────────────────────────────────
hdr "Phase 1: Homebrew"

if ! command -v brew &>/dev/null; then
    log "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    ok "Homebrew installed"
else
    ok "Homebrew already installed: $(brew --version | head -1)"
fi

# ── PHASE 2: Python ───────────────────────────────────────
hdr "Phase 2: Python 3"

if ! command -v python3 &>/dev/null || [[ $(python3 -c "import sys; print(sys.version_info >= (3,9))") != "True" ]]; then
    log "Installing Python 3.11..."
    brew install python@3.11
fi
ok "Python: $(python3 --version)"

# ── PHASE 3: Java (required for Android build) ────────────
hdr "Phase 3: Java 17"

if ! command -v java &>/dev/null || ! java -version 2>&1 | grep -q "17\|21"; then
    log "Installing OpenJDK 17..."
    brew install --cask temurin17
fi
ok "Java: $(java -version 2>&1 | head -1)"

# ── PHASE 4: Flutter ──────────────────────────────────────
hdr "Phase 4: Flutter"

FLUTTER_DIR="$HOME/flutter"

if [ ! -d "$FLUTTER_DIR" ]; then
    log "Cloning Flutter stable (this takes 2-5 min)..."
    git clone https://github.com/flutter/flutter.git -b stable "$FLUTTER_DIR" --depth 1
    ok "Flutter cloned"
else
    ok "Flutter already at $FLUTTER_DIR"
fi

# Add Flutter to PATH for this session
export PATH="$PATH:$FLUTTER_DIR/bin"

# Also add to shell profile permanently
SHELL_RC="$HOME/.zshrc"
[ -f "$HOME/.bash_profile" ] && SHELL_RC="$HOME/.bash_profile"

if ! grep -q "flutter/bin" "$SHELL_RC" 2>/dev/null; then
    echo '' >> "$SHELL_RC"
    echo '# Flutter' >> "$SHELL_RC"
    echo "export PATH=\"\$PATH:$FLUTTER_DIR/bin\"" >> "$SHELL_RC"
    ok "Flutter added to $SHELL_RC"
fi

# ── PHASE 5: Android SDK ──────────────────────────────────
hdr "Phase 5: Android SDK (command-line tools)"

ANDROID_HOME="$HOME/android-sdk"
export ANDROID_HOME
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/34.0.0"

if [ ! -d "$ANDROID_HOME/cmdline-tools" ]; then
    log "Downloading Android command-line tools..."
    mkdir -p "$ANDROID_HOME/cmdline-tools"
    
    TMP_ZIP="/tmp/android-cmdline-tools.zip"
    curl -L "https://dl.google.com/android/repository/commandlinetools-mac-11076708_latest.zip" \
         -o "$TMP_ZIP" --progress-bar
    
    unzip -q "$TMP_ZIP" -d "$ANDROID_HOME/cmdline-tools"
    
    # Google packages it as 'cmdline-tools', rename to 'latest'
    if [ -d "$ANDROID_HOME/cmdline-tools/cmdline-tools" ]; then
        mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
    fi
    rm -f "$TMP_ZIP"
    ok "Android cmdline-tools installed"
else
    ok "Android cmdline-tools already present"
fi

# Add Android SDK to shell profile
if ! grep -q "ANDROID_HOME" "$SHELL_RC" 2>/dev/null; then
    echo '' >> "$SHELL_RC"
    echo '# Android SDK' >> "$SHELL_RC"
    echo "export ANDROID_HOME=\"$ANDROID_HOME\"" >> "$SHELL_RC"
    echo "export ANDROID_SDK_ROOT=\"$ANDROID_HOME\"" >> "$SHELL_RC"
    echo 'export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/34.0.0"' >> "$SHELL_RC"
fi

# Accept licenses and install build tools
log "Accepting Android SDK licenses..."
yes | sdkmanager --licenses 2>/dev/null || true

log "Installing Android build tools and platform..."
sdkmanager \
    "platform-tools" \
    "build-tools;34.0.0" \
    "platforms;android-34" \
    --sdk_root="$ANDROID_HOME" 2>&1 | grep -E "^(Installing|Unzipping|done)" || true

ok "Android SDK ready"

# ── PHASE 6: Backend Python deps ──────────────────────────
hdr "Phase 6: Backend Python Dependencies"

log "Installing Python packages for face recognition..."
pip3 install \
    fastapi \
    "uvicorn[standard]" \
    python-multipart \
    insightface \
    onnxruntime \
    faiss-cpu \
    opencv-python-headless \
    Pillow \
    numpy \
    aiofiles \
    --quiet

ok "Python backend dependencies installed"

# ── PHASE 7: Copy photos ──────────────────────────────────
hdr "Phase 7: Photo Setup"

mkdir -p "$SCRIPT_DIR/photos"
PHOTOS_01="$HOME/Downloads/01"

if [ -d "$PHOTOS_01" ]; then
    PHOTO_COUNT=$(find "$PHOTOS_01" -type f \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" \) | wc -l | tr -d ' ')
    log "Found $PHOTO_COUNT photos in ~/Downloads/01 — copying..."
    cp -r "$PHOTOS_01/"* "$SCRIPT_DIR/photos/" 2>/dev/null || true
    ok "Copied $PHOTO_COUNT photos to ./photos/"
else
    warn "~/Downloads/01 not found."
    warn "Copy your event photos to: $SCRIPT_DIR/photos/"
fi

# ── PHASE 8: Index photos ─────────────────────────────────
hdr "Phase 8: Index Photos (AI Face Extraction)"

if [ "$(ls -A "$SCRIPT_DIR/photos" 2>/dev/null)" ]; then
    PHOTO_COUNT=$(find "$SCRIPT_DIR/photos" -type f \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" \) | wc -l | tr -d ' ')
    log "Indexing $PHOTO_COUNT photos..."
    log "(First run downloads the InsightFace AI model ~500MB — be patient)"
    echo ""
    python3 "$SCRIPT_DIR/backend/index_photos.py" \
        --photos "$SCRIPT_DIR/photos" \
        --index "$SCRIPT_DIR/index_data"
    ok "Photos indexed!"
else
    warn "No photos to index yet. Add photos to ./photos/ then run:"
    warn "  python3 backend/index_photos.py --photos photos"
fi

# ── PHASE 9: Build Flutter APK ────────────────────────────
hdr "Phase 9: Build Android APK"

APP_DIR="$SCRIPT_DIR/flutter_app/photofinder"
cd "$APP_DIR"

log "Getting Flutter packages..."
flutter pub get 2>&1 | tail -5

log "Building release APK (3-8 minutes)..."
flutter build apk --release 2>&1 | grep -E "(Building|Built|Error|error)" | tail -20

APK_SRC="$APP_DIR/build/app/outputs/flutter-apk/app-release.apk"
APK_DST="$SCRIPT_DIR/PhotoFinder.apk"

if [ -f "$APK_SRC" ]; then
    cp "$APK_SRC" "$APK_DST"
    APK_SIZE=$(ls -lh "$APK_DST" | awk '{print $5}')
    
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║   🎉 APK BUILD COMPLETE!                 ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
    echo ""
    ok "APK: $APK_DST ($APK_SIZE)"
    echo ""
    echo -e "${YELLOW}📱 To install on your Android phone:${NC}"
    echo "   adb install $APK_DST"
    echo "   — OR —"
    echo "   Transfer PhotoFinder.apk to your phone and tap to install"
    echo "   (Enable: Settings → Apps → Install unknown apps)"
    echo ""
else
    warn "APK build may have failed. Check output above."
    warn "Try manually: cd flutter_app/photofinder && flutter build apk --release --verbose"
fi

cd "$SCRIPT_DIR"

# ── FINAL: Print your server IP ───────────────────────────
hdr "Your Server Info"

MY_IP=$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "UNKNOWN")
echo -e "  ${BOLD}Server URL for the app:${NC}  http://$MY_IP:8000"
echo ""
echo -e "  ${BOLD}Start server anytime with:${NC}"
echo "    bash start_server.sh"
echo ""
echo -e "  ${BOLD}Or manually:${NC}"
echo "    uvicorn backend.main:app --host 0.0.0.0 --port 8000"
echo ""
echo -e "${GREEN}Setup complete! 🚀${NC}"
